function my_function()
{
    
    
    eel.my_function(data)(change)
}
function change(ret)
{
    document.getElementById("test").innerHTML=ret;
}